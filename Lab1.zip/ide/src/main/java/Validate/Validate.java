package Validate;

import java.util.Scanner;

public class Validate {
    public String valid() {
        Scanner sc = new Scanner(System.in);
        int number; // вводимое число
        System.out.println("Введите систму счисления: 2, 8, 10, 16");

        int numeralSystem = ChoceNS.choiceNumSys();

        System.out.println("Введите число: ");
        try {
            number = Integer.parseInt(sc.nextLine(), numeralSystem);

            return Long.toString(number);
        } catch (NumberFormatException e) {
            System.out.println("неверно введено число");
        }
        return null;
    }

}