package Validate;

import java.util.Scanner;

public class ChoceNS {


    public static int choiceNumSys() {
        try {


            Scanner scan = new Scanner(System.in);
            int nsnumb = scan.nextInt();
            int numeralSystem = 0;
            switch (nsnumb) {
                case 2:
                    numeralSystem = 2;
                    break;
                case 8:
                    numeralSystem = 8;
                    break;
                case 10:
                    numeralSystem = 10;
                    break;
                case 16:
                    numeralSystem = 16;
                    break;


            }
            return numeralSystem;
        } catch (NumberFormatException e) {
            System.out.println("неверно введено число");
        }
        return 0;
    }
}

