package NumSystem;

public class Hex implements NumSys {
    @Override
    public void choiceNumSys(String s) {
        System.out.println(Long.toHexString(Long.parseLong(s)));
    }
}