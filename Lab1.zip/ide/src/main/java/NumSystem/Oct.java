package NumSystem;

public class Oct implements NumSys {
    @Override
    public void choiceNumSys(String s) {
        System.out.println(Long.toOctalString(Long.parseLong(s)));
    }
}