package NumSystem;


public class FactoryNumSys {
    public static NumSys createNumSys(NumeralSystem type) {
        NumSys numsys = null;

        switch (type) {

            case BIN:
                numsys = new Bin();
                break;

            case OCT:
                numsys = new Oct();
                break;
            case DEC:
                numsys = new Dec();
                break;
            case HEX:
                numsys = new Hex();
                break;
        }
        return numsys;
    }
}
