package NumSystem;

public enum NumeralSystem {
    BIN, OCT, DEC, HEX;
}
