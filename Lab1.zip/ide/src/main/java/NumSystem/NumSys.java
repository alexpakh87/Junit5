package NumSystem;

import java.util.Scanner;

public interface NumSys {
    void choiceNumSys(String s);

}
