package Operation;

import NumSystem.FactoryNumSys;
import NumSystem.NumSys;
import NumSystem.NumeralSystem;
import Validate.Validate;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Validate val = new Validate();


        int s = Integer.parseInt(val.valid());
        int ss = Integer.parseInt(val.valid());

        System.out.println("Выбирите операцию:ADDITION, SUBTRACTION, MULTIPLICATION, DIVISION");
        OperationType type = OperationType.valueOf(scan.nextLine());


        Operation op = FactoryOperation.creatOperation(type);
        int result = op.operation(s, ss);
        System.out.println("Введите систему счисления полученного результата: BIN OCT DEC HEX");


        String bi = scan.nextLine();
        NumSys numeralSystem = FactoryNumSys.createNumSys(NumeralSystem.valueOf(bi));
        numeralSystem.choiceNumSys(String.valueOf(result));


    }
}
