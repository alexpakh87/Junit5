package Operation;

public interface Operation {
    public int operation(int a, int b);
}
