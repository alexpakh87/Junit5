package Operation;

public enum OperationType {
    ADDITION, SUBTRACTION, MULTIPLICATION, DIVISION;
}
