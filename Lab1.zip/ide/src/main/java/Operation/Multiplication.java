package Operation;

public class Multiplication implements Operation {
    @Override
    public int operation(int a, int b) {

        return a * b;
    }
}
