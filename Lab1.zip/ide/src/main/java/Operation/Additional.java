package Operation;

public class Additional implements Operation {
    @Override
    public int operation(int a, int b) {

        return a + b;
    }
}
