package Operation;

public class Division implements Operation {
    @Override
    public int operation(int a, int b) {

        return a / b;
    }
}
