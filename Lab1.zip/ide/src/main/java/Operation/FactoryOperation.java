package Operation;

public class FactoryOperation {
    public static Operation creatOperation(OperationType type) {
        Operation operation = null;
        switch (type) {
            case ADDITION:
                operation = new Additional();
                break;
            case DIVISION:
                operation = new Division();
                break;
            case SUBTRACTION:
                operation = new Subtraction();
                break;
            case MULTIPLICATION:
                operation = new Multiplication();
                break;
        }
        return operation;
    }
}
